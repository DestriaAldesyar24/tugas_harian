package com.example;

class PokemonResult {
    String name;
    String url;
}