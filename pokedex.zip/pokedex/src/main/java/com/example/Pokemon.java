package com.example;

public class Pokemon {
    int count;
    PokemonResult[] results;
}
